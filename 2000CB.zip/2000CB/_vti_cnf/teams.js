vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Nov 2002 13:17:46 -0000
vti_extenderversion:SR|4.0.2.6513
vti_backlinkinfo:VX|2000cb/team.html
