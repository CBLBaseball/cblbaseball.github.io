vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Mar 2002 18:11:58 -0000
vti_extenderversion:SR|4.0.2.6513
vti_backlinkinfo:VX|2000cb/bplayer.html 2000cb/pplayer.html
