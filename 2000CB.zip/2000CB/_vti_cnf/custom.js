vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Sep 2003 23:00:56 -0000
vti_extenderversion:SR|4.0.2.6513
vti_backlinkinfo:VX|2000cb/bplayer.html 2000cb/index.html 2000cb/leaders.html 2000cb/team.html 2000cb/pplayer.html 2000cb/grand2.html 2000cb/grand1.html
