vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Sep 2003 22:43:46 -0000
vti_extenderversion:SR|4.0.2.6513
