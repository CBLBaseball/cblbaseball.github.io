leaderName0 = new Array( "B.Williams", "R.Cedeno", "N.Garciaparra", "L.Gonzalez", "M.Sweeney", "F.Thomas", "H.Rodriguez", "S.Green", "D.Young", "E.Martinez" );
leaderTeam0 = new Array( "CHN", "HON", "BOA", "DEA", "KCA", "CHA", "CHN", "SEA", "SFN", "LAN" );
leaderData0 = new Array( ".365", ".359", ".354", ".352", ".348", ".347", ".344", ".337", ".336", ".335" );

leaderName1 = new Array( "V.Guerrero", "C.Biggio", "B.Williams", "B.Surhoff", "E.Alfonzo", "I.Rodriguez", "R.Alomar", "J.Randa", "S.Sosa", "D.Glanville" );
leaderTeam1 = new Array( "MON", "HON", "CHN", "CIN", "NYN", "MON", "MON", "KCA", "CHN", "PHN" );
leaderData1 = new Array( "682", "675", "671", "669", "669", "662", "656", "655", "652", "650" );

leaderName2 = new Array( "S.Sosa", "M.McGwire", "B.Williams", "R.Alomar", "J.Bagwell", "B.Giles", "S.Green", "E.Alfonzo", "C.Jones", "J.Thome" );
leaderTeam2 = new Array( "CHN", "OAA", "CHN", "MON", "HON", "SEA", "SEA", "NYN", "HON", "CLA" );
leaderData2 = new Array( "141", "139", "139", "137", "135", "134", "134", "131", "126", "123" );

leaderName3 = new Array( "B.Williams", "L.Gonzalez", "M.Sweeney", "I.Rodriguez", "S.Green", "V.Guerrero", "E.Alfonzo", "B.Surhoff", "R.Alomar", "J.Vidro" );
leaderTeam3 = new Array( "CHN", "DEA", "KCA", "MON", "SEA", "MON", "NYN", "CIN", "MON", "SEA" );
leaderData3 = new Array( "245", "223", "209", "208", "206", "205", "205", "204", "204", "202" );

leaderName4 = new Array( "J.Vidro", "L.Gonzalez", "M.Sweeney", "C.Delgado", "D.Young", "G.Anderson", "G.Jenkins", "J.Varitek", "S.Green", "R.Greer" );
leaderTeam4 = new Array( "SEA", "DEA", "KCA", "SEA", "SFN", "LAN", "SFN", "BOA", "SEA", "NYA" );
leaderData4 = new Array( "61", "54", "53", "52", "52", "51", "51", "49", "49", "48" );

leaderName5 = new Array( "S.Finley", "D.Jeter", "M.Cameron", "T.Goodwin", "J.Damon", "A.Gonzalez", "N.Perez", "B.Abreu", "M.Tucker", "R.Clayton" );
leaderTeam5 = new Array( "LAN", "NYA", "SEA", "SLN", "KCA", "MNA", "HON", "PHN", "BAA", "BAA" );
leaderData5 = new Array( "18", "15", "15", "14", "13", "12", "12", "10", "9", "9" );

leaderName6 = new Array( "M.McGwire", "S.Sosa", "S.Green", "V.Guerrero", "M.Ramirez", "B.Giles", "A.Rodriguez", "R.Palmeiro", "C.Delgado", "K.Griffey Jr." );
leaderTeam6 = new Array( "OAA", "CHN", "SEA", "MON", "CLA", "SEA", "SEA", "CHN", "SEA", "ATN" );
leaderData6 = new Array( "69", "58", "51", "49", "47", "46", "45", "44", "43", "43" );

leaderName7 = new Array( "M.McGwire", "S.Sosa", "V.Guerrero", "M.Ramirez", "R.Palmeiro", "M.Williams", "C.Jones", "E.Karros", "D.Young", "S.Green" );
leaderTeam7 = new Array( "OAA", "CHN", "MON", "CLA", "CHN", "CHN", "HON", "LAN", "SFN", "SEA" );
leaderData7 = new Array( "169", "169", "159", "151", "143", "142", "140", "138", "135", "134" );

leaderName8 = new Array( "J.Bagwell", "M.McGwire", "J.Olerud", "J.Thome", "E.Martinez", "C.Jones", "B.Larkin", "R.Alomar", "B.Williams", "B.Abreu" );
leaderTeam8 = new Array( "HON", "OAA", "NYN", "CLA", "LAN", "HON", "CIN", "MON", "CHN", "PHN" );
leaderData8 = new Array( "150", "149", "129", "124", "119", "114", "109", "109", "104", "102" );

leaderName9 = new Array( "M.McGwire", "A.Belle", "H.Baines", "L.Walker", "E.Martinez", "M.Ramirez", "S.Rolen", "J.Burnitz", "C.Delgado", "R.Palmeiro" );
leaderTeam9 = new Array( "OAA", "BAA", "KCA", "CHA", "LAN", "CLA", "DEA", "DEA", "SEA", "CHN" );
leaderData9 = new Array( "29", "6", "5", "4", "4", "3", "3", "3", "3", "3" );

leaderName10 = new Array( "S.Sosa", "L.Stevens", "R.Rivera", "E.Karros", "J.Thome", "G.Vaughn", "D.Palmer", "M.Ramirez", "J.Bagwell", "J.Hernandez" );
leaderTeam10 = new Array( "CHN", "SLN", "ANA", "LAN", "CLA", "SDN", "NYN", "CLA", "HON", "CHN" );
leaderData10 = new Array( "188", "183", "169", "168", "167", "167", "164", "159", "154", "152" );

leaderName11 = new Array( "B.Anderson", "L.Walker", "E.Sprague", "J.Burnitz", "M.Ramirez", "F.Santangelo", "J.Kendall", "D.Easley", "F.Tatis", "D.Jeter" );
leaderTeam11 = new Array( "BAA", "CHA", "SDN", "DEA", "CLA", "NYN", "PIN", "DEA", "SLN", "NYA" );
leaderData11 = new Array( "25", "23", "23", "22", "20", "20", "20", "17", "17", "16" );

leaderName12 = new Array( "R.Ordonez", "L.Castillo", "M.McLemore", "D.Lewis", "J.Girardi", "J.McEwing", "M.Johnson", "M.Bordick", "F.Vina", "C.Guzman" );
leaderTeam12 = new Array( "NYN", "CHN", "SLN", "NYN", "NYA", "SLN", "CHA", "SDN", "SDN", "MNA" );
leaderData12 = new Array( "65", "32", "21", "17", "13", "12", "11", "10", "10", "9" );

leaderName13 = new Array( "R.Cedeno", "T.Goodwin", "Q.Veras", "B.Hunter", "H.Bush", "R.Henderson", "L.Castillo", "E.Owens", "O.Vizquel", "D.Glanville" );
leaderTeam13 = new Array( "HON", "SLN", "ANA", "PHN", "TOA", "ATN", "CHN", "ANA", "CLA", "PHN" );
leaderData13 = new Array( "69", "66", "64", "63", "60", "60", "54", "44", "44", "44" );

leaderName14 = new Array( "C.Everett", "R.Alomar", "L.Johnson", "B.Hunter", "S.Green", "T.Womack", "C.Beltran", "T.Hunter", "A.Boone", "M.Benard" );
leaderTeam14 = new Array( "HON", "MON", "TOA", "PHN", "SEA", "SFN", "KCA", "MNA", "CIN", "SFN" );
leaderData14 = new Array( "1.00", ".93", ".91", ".90", ".88", ".87", ".86", ".86", ".86", ".85" );

leaderName15 = new Array( "I.Rodriguez", "R.Durham", "D.Easley", "R.Velarde", "J.Cirillo", "C.Jones", "V.Guerrero", "T.O'Leary", "M.Lieberthal", "T.Gwynn" );
leaderTeam15 = new Array( "MON", "CHA", "DEA", "OAA", "OAA", "HON", "MON", "BOA", "PHN", "SDN" );
leaderData15 = new Array( "31", "30", "29", "29", "28", "27", "27", "26", "26", "26" );

leaderName16 = new Array( "J.Thome", "H.Bush", "E.Alfonzo", "R.Cedeno", "D.Segui", "B.Daubach", "L.Polonia", "J.Hernandez", "J.Gonzalez", "C.Ripken Jr." );
leaderTeam16 = new Array( "CLA", "TOA", "NYN", "HON", "TOA", "BOA", "DEA", "CHN", "MON", "BAA" );
leaderData16 = new Array( "15", "15", "15", "14", "12", "10", "10", "10", "10", "9" );

leaderName17 = new Array( "J.Hammonds", "G.Colbrunn", "J.Jones", "", "", "", "", "", "", "" );
leaderTeam17 = new Array( "CLA", "LAN", "MNA", "", "", "", "", "", "", "" );
leaderData17 = new Array( ".364", ".321", ".273", "0", "0", "0", "0", "0", "0", "0" );

leaderName18 = new Array( "M.McGwire", "S.Green", "L.Walker", "J.Canseco", "C.Delgado", "R.Klesko", "B.Giles", "M.Ramirez", "A.Rodriguez", "L.Gonzalez" );
leaderTeam18 = new Array( "OAA", "SEA", "CHA", "CLA", "SEA", "ATN", "SEA", "CLA", "SEA", "DEA" );
leaderData18 = new Array( ".690", ".668", ".621", ".621", ".620", ".616", ".614", ".609", ".608", ".606" );

leaderName19 = new Array( "E.Martinez", "B.Williams", "F.Thomas", "J.Olerud", "R.Cedeno", "P.O'Neill", "M.Sweeney", "D.Jeter", "B.Abreu", "J.Bagwell" );
leaderTeam19 = new Array( "LAN", "CHN", "CHA", "NYN", "HON", "CIN", "KCA", "NYA", "PHN", "HON" );
leaderData19 = new Array( ".459", ".449", ".444", ".440", ".437", ".431", ".428", ".426", ".422", ".422" );

leaderName20 = new Array( "E.Martinez", "B.Williams", "S.Green", "M.McGwire", "L.Gonzalez", "M.Sweeney", "L.Walker", "F.Thomas", "R.Klesko", "M.Ramirez" );
leaderTeam20 = new Array( "LAN", "CHN", "SEA", "OAA", "DEA", "KCA", "CHA", "CHA", "ATN", "CLA" );
leaderData20 = new Array( "10.7", "10.6", "10.3", "10.1", " 9.9", " 9.9", " 9.5", " 9.5", " 9.3", " 9.3" );

leaderName21 = new Array( "M.McGwire", "S.Green", "E.Martinez", "B.Williams", "L.Walker", "M.Ramirez", "L.Gonzalez", "B.Giles", "M.Sweeney", "R.Palmeiro" );
leaderTeam21 = new Array( "OAA", "SEA", "LAN", "CHN", "CHA", "CLA", "DEA", "SEA", "KCA", "CHN" );
leaderData21 = new Array( "1.245", "1.192", "1.156", "1.121", "1.118", "1.092", "1.081", "1.078", "1.076", "1.069" );

leaderName22 = new Array( "V.Guerrero", "S.Green", "B.Williams", "L.Gonzalez", "M.McGwire", "C.Delgado", "M.Williams", "S.Sosa", "I.Rodriguez", "M.Ramirez" );
leaderTeam22 = new Array( "MON", "SEA", "CHN", "DEA", "OAA", "SEA", "CHN", "CHN", "MON", "CLA" );
leaderData22 = new Array( "409", "408", "386", "384", "378", "374", "373", "360", "359", "356" );

leaderName23 = new Array( "C.Singleton", "L.Walker", "M.Sweeney", "T.O'Leary", "K.Caminiti", "N.Garciaparra", "D.Palmer", "M.Bordick", "M.Cairo", "R.Velarde" );
leaderTeam23 = new Array( "CHA", "CHA", "KCA", "BOA", "PIN", "BOA", "NYN", "SDN", "CIN", "OAA" );
leaderData23 = new Array( ".441", ".411", ".405", ".394", ".393", ".387", ".384", ".383", ".382", ".375" );

leaderName24 = new Array( "M.McGwire", "C.Jones", "D.Palmer", "J.Bell", "V.Guerrero", "J.Canseco", "I.Rodriguez", "E.Burks", "B.Huskey", "M.Cameron" );
leaderTeam24 = new Array( "OAA", "HON", "NYN", "ATN", "MON", "CLA", "MON", "PIN", "BOA", "SEA" );
leaderData24 = new Array( "19", "19", "19", "17", "17", "15", "15", "15", "14", "14" );

leaderName25 = new Array( "B.Williams", "R.Cedeno", "L.Gonzalez", "D.Jeter", "S.Green", "F.Thomas", "B.Abreu", "T.Shumpert", "N.Garciaparra", "S.Casey" );
leaderTeam25 = new Array( "CHN", "HON", "DEA", "NYA", "SEA", "CHA", "PHN", "SDN", "BOA", "CIN" );
leaderData25 = new Array( ".376", ".371", ".363", ".359", ".359", ".355", ".355", ".350", ".342", ".341" );

leaderName26 = new Array( "M.McGwire", "S.Sosa", "B.Giles", "S.Green", "M.Ramirez", "R.Palmeiro", "M.Piazza", "A.Rodriguez", "K.Griffey Jr.", "J.Thome" );
leaderTeam26 = new Array( "OAA", "CHN", "SEA", "SEA", "CLA", "CHN", "LAN", "SEA", "ATN", "CLA" );
leaderData26 = new Array( "50", "49", "41", "41", "37", "37", "37", "36", "36", "35" );

leaderName27 = new Array( "R.Johnson", "K.Brown", "P.Martinez", "K.Millwood", "J.Lima", "O.Hernandez", "G.Heredia", "M.Sirotka", "D.Hermanson", "M.Hampton" );
leaderTeam27 = new Array( "CHN", "CHN", "HON", "OAA", "HON", "NYA", "OAA", "CHA", "MON", "MON" );
leaderData27 = new Array( "25", "25", "24", "22", "22", "20", "20", "19", "18", "18" );

leaderName28 = new Array( "R.Person", "D.Kile", "S.Erickson", "J.Witasick", "M.Clement", "K.Rueter", "F.Cordova", "B.Radke", "F.Garcia", "M.Yoshii" );
leaderTeam28 = new Array( "PHN", "SLN", "BAA", "PHN", "SDN", "SFN", "CHA", "MNA", "SEA", "SLN" );
leaderData28 = new Array( "20", "20", "18", "18", "17", "17", "16", "16", "16", "16" );

leaderName29 = new Array( "K.Brown", "P.Martinez", "J.Smoltz", "J.Halama", "S.Karsay", "D.Dreifort", "D.Cone", "B.Colon", "R.Johnson", "M.Sirotka" );
leaderTeam29 = new Array( "CHN", "HON", "NYN", "SEA", "CLA", "LAN", "HON", "CLA", "CHN", "CHA" );
leaderData29 = new Array( ".893", ".857", ".810", ".778", ".765", ".765", ".739", ".727", ".714", ".704" );

leaderName30 = new Array( "P.Martinez", "O.Hernandez", "J.Smoltz", "M.Hampton", "K.Millwood", "K.Brown", "R.Johnson", "J.Halama", "J.Lima", "S.Hitchcock" );
leaderTeam30 = new Array( "HON", "NYA", "NYN", "MON", "OAA", "CHN", "CHN", "SEA", "HON", "NYA" );
leaderData30 = new Array( " 2.37", " 2.82", " 2.96", " 3.04", " 3.09", " 3.38", " 3.54", " 3.63", " 3.67", " 3.96" );

leaderName31 = new Array( "R.Johnson", "K.Brown", "J.Lima", "P.Martinez", "K.Millwood", "M.Hampton", "M.Mussina", "T.Glavine", "O.Hernandez", "D.Cone" );
leaderTeam31 = new Array( "CHN", "CHN", "HON", "HON", "OAA", "MON", "HON", "ATN", "NYA", "HON" );
leaderData31 = new Array( "292.1", "282.0", "269.2", "266.0", "265.1", "254.2", "250.0", "249.1", "249.0", "246.2" );

leaderName32 = new Array( "R.Johnson", "K.Brown", "J.Lima", "T.Glavine", "M.Hampton", "K.Millwood", "M.Mussina", "G.Maddux", "D.Cone", "S.Reynolds" );
leaderTeam32 = new Array( "CHN", "CHN", "HON", "ATN", "MON", "OAA", "HON", "ATN", "HON", "NYN" );
leaderData32 = new Array( "1209", "1147", "1118", "1099", "1091", "1080", "1076", "1073", "1058", "1053" );

leaderName33 = new Array( "U.Urbina", "M.Remlinger", "R.Nen", "A.Benitez", "J.Powell", "P.Shuey", "S.Williamson", "D.Lowe", "M.Venafro", "K.McGlinchy" );
leaderTeam33 = new Array( "MON", "TOA", "BOA", "MON", "SDN", "CLA", "CIN", "BOA", "BOA", "ANA" );
leaderData33 = new Array( "88", "82", "78", "76", "76", "74", "73", "72", "72", "71" );

leaderName34 = new Array( "T.Glavine", "R.Johnson", "K.Brown", "J.Lima", "R.Helling", "M.Hampton", "S.Reynolds", "S.Erickson", "A.Sele", "K.Appier" );
leaderTeam34 = new Array( "ATN", "CHN", "CHN", "HON", "LAN", "MON", "NYN", "BAA", "BOA", "KCA" );
leaderData34 = new Array( "35", "35", "35", "35", "35", "35", "35", "34", "34", "34" );

leaderName35 = new Array( "R.Johnson", "P.Martinez", "K.Brown", "K.Millwood", "O.Hernandez", "J.Lima", "M.Mussina", "O.Daal", "D.Cone", "J.Rosado" );
leaderTeam35 = new Array( "CHN", "HON", "CHN", "OAA", "NYA", "HON", "HON", "KCA", "HON", "KCA" );
leaderData35 = new Array( "26", "22", "20", "19", "17", "15", "15", "14", "13", "12" );

leaderName36 = new Array( "G.Swindell", "S.Williamson", "D.Lowe", "M.Stanton", "J.Shaw", "R.Aguilera", "K.Foulke", "J.Rocker", "J.Zimmerman", "A.Benitez" );
leaderTeam36 = new Array( "LAN", "CIN", "BOA", "SDN", "CLA", "MNA", "CHA", "ATN", "CHN", "MON" );
leaderData36 = new Array( "67", "66", "63", "55", "52", "52", "51", "51", "51", "51" );

leaderName37 = new Array( "D.Lowe", "R.Hernandez", "M.Stanton", "J.Shaw", "T.Hoffman", "G.Swindell", "M.Mantei", "A.Embree", "T.Percival", "B.Koch" );
leaderTeam37 = new Array( "BOA", "NYN", "SDN", "CLA", "OAA", "LAN", "PIN", "SFN", "ANA", "TOA" );
leaderData37 = new Array( "42", "39", "35", "33", "32", "32", "30", "30", "29", "29" );

leaderName38 = new Array( "R.Hernandez", "A.Embree", "M.Stanton", "R.Aguilera", "T.Percival", "A.Benitez", "D.Lowe", "M.Timlin", "K.Foulke", "J.Zimmerman" );
leaderTeam38 = new Array( "NYN", "SFN", "SDN", "MNA", "ANA", "MON", "BOA", "BAA", "CHA", "CHN" );
leaderData38 = new Array( ".929", ".909", ".897", ".893", ".879", ".844", ".840", ".828", ".824", ".824" );

leaderName39 = new Array( "O.Daal", "P.Martinez", "O.Hernandez", "K.Millwood", "G.Maddux", "R.Johnson", "R.Ortiz", "S.Ponson", "B.Saberhagen", "A.Benes" );
leaderTeam39 = new Array( "KCA", "HON", "NYA", "OAA", "ATN", "CHN", "SFN", "BAA", "BOA", "NYA" );
leaderData39 = new Array( "5", "5", "3", "3", "3", "3", "3", "2", "2", "2" );

leaderName40 = new Array( "G.Maddux", "S.Reynolds", "T.Glavine", "J.Lima", "B.Radke", "M.Mussina", "P.Astacio", "L.Hawkins", "G.Heredia", "R.Johnson" );
leaderTeam40 = new Array( "ATN", "NYN", "ATN", "HON", "MNA", "HON", "OAA", "ANA", "OAA", "CHN" );
leaderData40 = new Array( "301", "295", "280", "278", "274", "270", "269", "263", "257", "257" );

leaderName41 = new Array( "R.Person", "J.Lieber", "T.Glavine", "S.Ponson", "K.Benson", "S.Erickson", "J.Witasick", "D.Kile", "A.Sele", "P.Astacio" );
leaderTeam41 = new Array( "PHN", "PIN", "ATN", "BAA", "PIN", "BAA", "PHN", "SLN", "BOA", "OAA" );
leaderData41 = new Array( "162", "150", "148", "144", "144", "142", "142", "142", "141", "140" );

leaderName42 = new Array( "R.Person", "J.Lieber", "T.Glavine", "S.Reynolds", "K.Benson", "S.Ponson", "P.Astacio", "J.Witasick", "A.Sele", "J.Rosado" );
leaderTeam42 = new Array( "PHN", "PIN", "ATN", "NYN", "PIN", "BAA", "OAA", "PHN", "BOA", "KCA" );
leaderData42 = new Array( "155", "144", "142", "140", "133", "132", "132", "132", "129", "129" );

leaderName43 = new Array( "R.Person", "R.Johnson", "R.Helling", "A.Ashby", "D.Burba", "P.Astacio", "B.Radke", "S.Ponson", "J.Fassero", "D.Cone" );
leaderTeam43 = new Array( "PHN", "CHN", "LAN", "CHA", "CIN", "OAA", "MNA", "BAA", "SEA", "HON" );
leaderData43 = new Array( "51", "40", "39", "38", "38", "37", "36", "35", "35", "35" );

leaderName44 = new Array( "R.Person", "R.Ortiz", "F.Garcia", "S.Erickson", "C.Park", "D.Kile", "M.Hampton", "D.Cone", "R.Dempster", "A.Pettitte" );
leaderTeam44 = new Array( "PHN", "SFN", "SEA", "BAA", "LAN", "SLN", "MON", "HON", "SEA", "NYA" );
leaderData44 = new Array( "153", "130", "117", "116", "112", "112", "111", "109", "107", "106" );

leaderName45 = new Array( "P.Martinez", "R.Johnson", "D.Cone", "K.Brown", "K.Millwood", "M.Mussina", "S.Hitchcock", "S.Reynolds", "R.Person", "S.Williamson" );
leaderTeam45 = new Array( "HON", "CHN", "HON", "CHN", "OAA", "HON", "NYA", "NYN", "PHN", "CIN" );
leaderData45 = new Array( "379", "361", "235", "228", "223", "203", "201", "199", "196", "190" );

leaderName46 = new Array( "C.Carpenter", "F.Garcia", "S.Hitchcock", "S.Williamson", "A.Telemaco", "D.Veres", "A.Benes", "C.Park", "R.Ortiz", "W.Williams" );
leaderTeam46 = new Array( "TOA", "SEA", "NYA", "CIN", "PHN", "ANA", "NYA", "LAN", "SFN", "TOA" );
leaderData46 = new Array( "19", "18", "17", "15", "15", "14", "14", "14", "14", "13" );

leaderName47 = new Array( "J.Silva", "O.Daal", "G.Mota", "F.Garcia", "B.Kim", "S.Trachsel", "O.Dotel", "D.Dreifort", "K.Benson", "D.Oliver" );
leaderTeam47 = new Array( "PIN", "KCA", "KCA", "SEA", "SEA", "CHN", "HON", "LAN", "PIN", "SLN" );
leaderData47 = new Array( "8", "5", "5", "5", "5", "5", "5", "5", "5", "5" );

leaderName48 = new Array( "L.Hawkins", "H.Irabu", "F.Cordova", "C.Schilling", "B.Radke", "M.Mussina", "D.Cone", "P.Martinez", "C.Park", "D.Hermanson" );
leaderTeam48 = new Array( "ANA", "ANA", "CHA", "CHA", "MNA", "HON", "HON", "HON", "LAN", "MON" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "P.Astacio", "R.Johnson", "J.Guzman", "K.Millwood", "D.Wells", "K.Hill", "R.Rupe", "H.Nomo", "A.Leiter", "B.Bohanon" );
leaderTeam49 = new Array( "OAA", "CHN", "SDN", "OAA", "DEA", "ANA", "ATN", "MON", "NYN", "BAA" );
leaderData49 = new Array( "48", "47", "44", "43", "40", "36", "34", "34", "33", "32" );

leaderName50 = new Array( "S.Parris", "K.Appier", "D.Eiland", "J.Suppan", "S.Erickson", "F.Garcia", "D.Burba", "D.Kile", "J.Johnson", "R.Helling" );
leaderTeam50 = new Array( "CIN", "KCA", "OAA", "BOA", "BAA", "SEA", "CIN", "SLN", "SDN", "LAN" );
leaderData50 = new Array( ".62", ".62", ".63", ".64", ".64", ".65", ".67", ".67", ".67", ".67" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "P.Martinez", "O.Hernandez", "K.Millwood", "S.Williamson", "K.Brown", "D.Cone", "R.Johnson", "R.Dempster", "E.Milton", "M.Hampton" );
leaderTeam53 = new Array( "HON", "NYA", "OAA", "CIN", "CHN", "HON", "CHN", "SEA", "MNA", "MON" );
leaderData53 = new Array( " 6.2", " 6.7", " 7.2", " 7.4", " 7.4", " 7.7", " 7.9", " 8.0", " 8.2", " 8.2" );

leaderName54 = new Array( "P.Martinez", "B.Radke", "G.Heredia", "J.Lima", "S.Reynolds", "I.Valdes", "J.Moyer", "J.Lieber", "G.Maddux", "J.Smoltz" );
leaderTeam54 = new Array( "HON", "MNA", "OAA", "HON", "NYN", "LAN", "CHN", "PIN", "ATN", "NYN" );
leaderData54 = new Array( " 1.4", " 1.7", " 1.8", " 1.8", " 1.8", " 2.1", " 2.2", " 2.2", " 2.2", " 2.3" );

leaderName55 = new Array( "P.Martinez", "R.Johnson", "S.Williamson", "C.Finley", "R.Clemens", "H.Nomo", "R.Dempster", "D.Cone", "R.Person", "C.Schilling" );
leaderTeam55 = new Array( "HON", "CHN", "CIN", "CLA", "MON", "MON", "SEA", "HON", "PHN", "CHA" );
leaderData55 = new Array( "12.8", "11.1", "10.4", " 9.2", " 8.9", " 8.8", " 8.7", " 8.6", " 8.4", " 8.0" );

leaderName56 = new Array( "M.Hampton", "D.Oliver", "A.Pettitte", "O.Hernandez", "J.Halama", "O.Olivares", "J.Lima", "S.Karl", "P.Martinez", "K.Millwood" );
leaderTeam56 = new Array( "MON", "SLN", "NYA", "NYA", "SEA", "DEA", "HON", "NYA", "HON", "OAA" );
leaderData56 = new Array( " 0.60", " 0.65", " 0.67", " 0.80", " 0.83", " 0.86", " 0.87", " 0.87", " 0.88", " 0.88" );

