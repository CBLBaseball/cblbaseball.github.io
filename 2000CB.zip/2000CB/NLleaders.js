leaderName0 = new Array( "B.Williams", "R.Cedeno", "H.Rodriguez", "D.Young", "E.Martinez", "S.Casey", "P.O'Neill", "G.Anderson", "B.Abreu", "R.Klesko" );
leaderTeam0 = new Array( "CHN", "HON", "CHN", "SFN", "LAN", "CIN", "CIN", "LAN", "PHN", "ATN" );
leaderData0 = new Array( ".365", ".359", ".344", ".336", ".335", ".335", ".327", ".324", ".323", ".322" );

leaderName1 = new Array( "V.Guerrero", "C.Biggio", "B.Williams", "B.Surhoff", "E.Alfonzo", "I.Rodriguez", "R.Alomar", "S.Sosa", "D.Glanville", "K.Griffey Jr." );
leaderTeam1 = new Array( "MON", "HON", "CHN", "CIN", "NYN", "MON", "MON", "CHN", "PHN", "ATN" );
leaderData1 = new Array( "682", "675", "671", "669", "669", "662", "656", "652", "650", "649" );

leaderName2 = new Array( "S.Sosa", "B.Williams", "R.Alomar", "J.Bagwell", "E.Alfonzo", "C.Jones", "J.Olerud", "E.Martinez", "R.Palmeiro", "B.Larkin" );
leaderTeam2 = new Array( "CHN", "CHN", "MON", "HON", "NYN", "HON", "NYN", "LAN", "CHN", "CIN" );
leaderData2 = new Array( "141", "139", "137", "135", "131", "126", "123", "121", "120", "116" );

leaderName3 = new Array( "B.Williams", "I.Rodriguez", "V.Guerrero", "E.Alfonzo", "B.Surhoff", "R.Alomar", "M.Williams", "G.Anderson", "D.Glanville", "D.Young" );
leaderTeam3 = new Array( "CHN", "MON", "MON", "NYN", "CIN", "MON", "CHN", "LAN", "PHN", "SFN" );
leaderData3 = new Array( "245", "208", "205", "205", "204", "204", "201", "200", "194", "194" );

leaderName4 = new Array( "D.Young", "G.Anderson", "G.Jenkins", "R.Alomar", "C.Biggio", "H.Rodriguez", "K.Young", "R.Klesko", "E.Alfonzo", "E.Karros" );
leaderTeam4 = new Array( "SFN", "LAN", "SFN", "MON", "HON", "CHN", "PIN", "ATN", "NYN", "LAN" );
leaderData4 = new Array( "52", "51", "51", "48", "47", "46", "46", "45", "45", "44" );

leaderName5 = new Array( "S.Finley", "T.Goodwin", "N.Perez", "B.Abreu", "V.Guerrero", "R.Ledee", "D.Hamilton", "M.Grace", "R.Sanders", "E.Durazo" );
leaderTeam5 = new Array( "LAN", "SLN", "HON", "PHN", "MON", "SLN", "SDN", "CHN", "CIN", "HON" );
leaderData5 = new Array( "18", "14", "12", "10", "8", "8", "8", "7", "7", "7" );

leaderName6 = new Array( "S.Sosa", "V.Guerrero", "R.Palmeiro", "K.Griffey Jr.", "M.Williams", "M.Piazza", "E.Burks", "G.Vaughn", "C.Jones", "J.Gonzalez" );
leaderTeam6 = new Array( "CHN", "MON", "CHN", "ATN", "CHN", "LAN", "PIN", "SDN", "HON", "MON" );
leaderData6 = new Array( "58", "49", "44", "43", "42", "42", "42", "42", "40", "40" );

leaderName7 = new Array( "S.Sosa", "V.Guerrero", "R.Palmeiro", "M.Williams", "C.Jones", "E.Karros", "D.Young", "B.Surhoff", "K.Griffey Jr.", "M.Piazza" );
leaderTeam7 = new Array( "CHN", "MON", "CHN", "CHN", "HON", "LAN", "SFN", "CIN", "ATN", "LAN" );
leaderData7 = new Array( "169", "159", "143", "142", "140", "138", "135", "134", "129", "125" );

leaderName8 = new Array( "J.Bagwell", "J.Olerud", "E.Martinez", "C.Jones", "B.Larkin", "R.Alomar", "B.Williams", "B.Abreu", "M.Stairs", "F.McGriff" );
leaderTeam8 = new Array( "HON", "NYN", "LAN", "HON", "CIN", "MON", "CHN", "PHN", "NYN", "ATN" );
leaderData8 = new Array( "150", "129", "119", "114", "109", "109", "104", "102", "99", "98" );

leaderName9 = new Array( "E.Martinez", "R.Palmeiro", "C.Davis", "F.McGriff", "M.Grace", "S.Sosa", "J.Bagwell", "C.Biggio", "C.Everett", "G.Anderson" );
leaderTeam9 = new Array( "LAN", "CHN", "ATN", "ATN", "CHN", "CHN", "HON", "HON", "HON", "LAN" );
leaderData9 = new Array( "4", "3", "2", "2", "2", "2", "2", "2", "2", "2" );

leaderName10 = new Array( "S.Sosa", "L.Stevens", "E.Karros", "G.Vaughn", "D.Palmer", "J.Bagwell", "J.Hernandez", "M.Stairs", "K.Young", "F.Tatis" );
leaderTeam10 = new Array( "CHN", "SLN", "LAN", "SDN", "NYN", "HON", "CHN", "NYN", "PIN", "SLN" );
leaderData10 = new Array( "188", "183", "168", "167", "164", "154", "152", "149", "148", "143" );

leaderName11 = new Array( "E.Sprague", "F.Santangelo", "J.Kendall", "F.Tatis", "B.Jordan", "D.Palmer", "M.Lieberthal", "K.Young", "M.Bordick", "C.Biggio" );
leaderTeam11 = new Array( "SDN", "NYN", "PIN", "SLN", "MON", "NYN", "PHN", "PIN", "SDN", "HON" );
leaderData11 = new Array( "23", "20", "20", "17", "16", "16", "16", "16", "15", "14" );

leaderName12 = new Array( "R.Ordonez", "L.Castillo", "M.McLemore", "D.Lewis", "J.McEwing", "M.Bordick", "F.Vina", "C.Wilson", "D.Deshields", "N.Perez" );
leaderTeam12 = new Array( "NYN", "CHN", "SLN", "NYN", "SLN", "SDN", "SDN", "MON", "SDN", "HON" );
leaderData12 = new Array( "65", "32", "21", "17", "12", "10", "10", "9", "9", "8" );

leaderName13 = new Array( "R.Cedeno", "T.Goodwin", "B.Hunter", "R.Henderson", "L.Castillo", "D.Glanville", "E.Young", "B.Larkin", "M.Benard", "E.Renteria" );
leaderTeam13 = new Array( "HON", "SLN", "PHN", "ATN", "CHN", "PHN", "LAN", "CIN", "SFN", "LAN" );
leaderData13 = new Array( "69", "66", "63", "60", "54", "44", "37", "35", "33", "31" );

leaderName14 = new Array( "C.Everett", "R.Alomar", "B.Hunter", "T.Womack", "A.Boone", "M.Benard", "L.Castillo", "R.Sanders", "P.Reese", "K.Lofton" );
leaderTeam14 = new Array( "HON", "MON", "PHN", "SFN", "CIN", "SFN", "CHN", "CIN", "SFN", "SFN" );
leaderData14 = new Array( "1.00", ".93", ".90", ".87", ".86", ".85", ".83", ".83", ".82", ".82" );

leaderName15 = new Array( "I.Rodriguez", "C.Jones", "V.Guerrero", "M.Lieberthal", "T.Gwynn", "M.Piazza", "B.Abreu", "M.Barrett", "R.Aurilia", "E.Alfonzo" );
leaderTeam15 = new Array( "MON", "HON", "MON", "PHN", "SDN", "LAN", "PHN", "PHN", "SFN", "NYN" );
leaderData15 = new Array( "31", "27", "27", "26", "26", "25", "25", "25", "25", "24" );

leaderName16 = new Array( "E.Alfonzo", "R.Cedeno", "J.Hernandez", "J.Gonzalez", "O.Merced", "R.Klesko", "F.McGriff", "V.Guerrero", "J.Olerud", "M.Benjamin" );
leaderTeam16 = new Array( "NYN", "HON", "CHN", "MON", "MON", "ATN", "ATN", "MON", "NYN", "PIN" );
leaderData16 = new Array( "15", "14", "10", "10", "9", "8", "8", "8", "8", "8" );

leaderName17 = new Array( "G.Colbrunn", "", "", "", "", "", "", "", "", "" );
leaderTeam17 = new Array( "LAN", "", "", "", "", "", "", "", "", "" );
leaderData17 = new Array( ".321", "0", "0", "0", "0", "0", "0", "0", "0", "0" );

leaderName18 = new Array( "R.Klesko", "V.Guerrero", "R.Palmeiro", "D.Young", "H.Rodriguez", "M.Williams", "B.Williams", "R.Sanders", "E.Martinez", "S.Sosa" );
leaderTeam18 = new Array( "ATN", "MON", "CHN", "SFN", "CHN", "CHN", "CHN", "CIN", "LAN", "CHN" );
leaderData18 = new Array( ".616", ".600", ".598", ".597", ".593", ".587", ".575", ".571", ".563", ".552" );

leaderName19 = new Array( "E.Martinez", "B.Williams", "J.Olerud", "R.Cedeno", "P.O'Neill", "B.Abreu", "J.Bagwell", "K.Lofton", "R.Palmeiro", "R.Alomar" );
leaderTeam19 = new Array( "LAN", "CHN", "NYN", "HON", "CIN", "PHN", "HON", "SFN", "CHN", "MON" );
leaderData19 = new Array( ".459", ".449", ".440", ".437", ".431", ".422", ".422", ".416", ".411", ".410" );

leaderName20 = new Array( "E.Martinez", "B.Williams", "R.Klesko", "R.Palmeiro", "D.Young", "H.Rodriguez", "R.Alomar", "R.Cedeno", "J.Bagwell", "P.O'Neill" );
leaderTeam20 = new Array( "LAN", "CHN", "ATN", "CHN", "SFN", "CHN", "MON", "HON", "HON", "CIN" );
leaderData20 = new Array( "10.7", "10.6", " 9.3", " 9.3", " 9.0", " 8.9", " 8.5", " 8.4", " 8.4", " 8.4" );

leaderName21 = new Array( "E.Martinez", "B.Williams", "R.Palmeiro", "R.Klesko", "R.Sanders", "J.Bagwell", "R.Cedeno", "P.O'Neill", "R.Alomar", "D.Young" );
leaderTeam21 = new Array( "LAN", "CHN", "CHN", "ATN", "CIN", "HON", "HON", "CIN", "MON", "SFN" );
leaderData21 = new Array( "1.156", "1.121", "1.069", "1.056", "1.054", "1.053", "1.026", "1.015", "1.011", "1.010" );

leaderName22 = new Array( "V.Guerrero", "B.Williams", "M.Williams", "S.Sosa", "I.Rodriguez", "R.Palmeiro", "E.Alfonzo", "D.Young", "B.Surhoff", "K.Griffey Jr." );
leaderTeam22 = new Array( "MON", "CHN", "CHN", "CHN", "MON", "CHN", "NYN", "SFN", "CIN", "ATN" );
leaderData22 = new Array( "409", "386", "373", "360", "359", "351", "346", "345", "338", "337" );

leaderName23 = new Array( "K.Caminiti", "D.Palmer", "M.Bordick", "M.Cairo", "M.Redmond", "B.Surhoff", "E.Burks", "S.Servais", "P.Wilson", "M.Lieberthal" );
leaderTeam23 = new Array( "PIN", "NYN", "SDN", "CIN", "CIN", "CIN", "PIN", "NYN", "HON", "PHN" );
leaderData23 = new Array( ".393", ".384", ".383", ".382", ".363", ".356", ".350", ".342", ".340", ".340" );

leaderName24 = new Array( "C.Jones", "D.Palmer", "J.Bell", "V.Guerrero", "I.Rodriguez", "E.Burks", "P.Wilson", "M.Stanley", "B.Surhoff", "J.Gonzalez" );
leaderTeam24 = new Array( "HON", "NYN", "ATN", "MON", "MON", "PIN", "HON", "CIN", "CIN", "MON" );
leaderData24 = new Array( "19", "19", "17", "17", "15", "15", "13", "12", "12", "12" );

leaderName25 = new Array( "B.Williams", "R.Cedeno", "B.Abreu", "T.Shumpert", "S.Casey", "H.Rodriguez", "J.Olerud", "G.Anderson", "D.Young", "P.O'Neill" );
leaderTeam25 = new Array( "CHN", "HON", "PHN", "SDN", "CIN", "CHN", "NYN", "LAN", "SFN", "CIN" );
leaderData25 = new Array( ".376", ".371", ".355", ".350", ".341", ".340", ".339", ".337", ".337", ".335" );

leaderName26 = new Array( "S.Sosa", "R.Palmeiro", "M.Piazza", "K.Griffey Jr.", "M.Williams", "V.Guerrero", "R.Klesko", "B.Williams", "G.Vaughn", "J.Bagwell" );
leaderTeam26 = new Array( "CHN", "CHN", "LAN", "ATN", "CHN", "MON", "ATN", "CHN", "SDN", "HON" );
leaderData26 = new Array( "49", "37", "37", "36", "33", "32", "31", "31", "30", "28" );

leaderName27 = new Array( "R.Johnson", "K.Brown", "P.Martinez", "J.Lima", "D.Hermanson", "M.Hampton", "M.Mussina", "D.Cone", "J.Smoltz", "J.Moyer" );
leaderTeam27 = new Array( "CHN", "CHN", "HON", "HON", "MON", "MON", "HON", "HON", "NYN", "CHN" );
leaderData27 = new Array( "25", "25", "24", "22", "18", "18", "17", "17", "17", "16" );

leaderName28 = new Array( "R.Person", "D.Kile", "J.Witasick", "M.Clement", "K.Rueter", "M.Yoshii", "R.Ortiz", "R.Wolf", "K.Benson", "J.Lieber" );
leaderTeam28 = new Array( "PHN", "SLN", "PHN", "SDN", "SFN", "SLN", "SFN", "PHN", "PIN", "PIN" );
leaderData28 = new Array( "20", "20", "18", "17", "17", "16", "16", "15", "15", "15" );

leaderName29 = new Array( "K.Brown", "P.Martinez", "J.Smoltz", "D.Dreifort", "D.Cone", "R.Johnson", "M.Hampton", "J.Lima", "D.Mlicki", "S.Trachsel" );
leaderTeam29 = new Array( "CHN", "HON", "NYN", "LAN", "HON", "CHN", "MON", "HON", "LAN", "CHN" );
leaderData29 = new Array( ".893", ".857", ".810", ".765", ".739", ".714", ".692", ".688", ".684", ".667" );

leaderName30 = new Array( "P.Martinez", "J.Smoltz", "M.Hampton", "K.Brown", "R.Johnson", "J.Lima", "D.Dreifort", "S.Williamson", "M.Mussina", "D.Cone" );
leaderTeam30 = new Array( "HON", "NYN", "MON", "CHN", "CHN", "HON", "LAN", "CIN", "HON", "HON" );
leaderData30 = new Array( " 2.37", " 2.96", " 3.04", " 3.38", " 3.54", " 3.67", " 3.99", " 4.00", " 4.03", " 4.05" );

leaderName31 = new Array( "R.Johnson", "K.Brown", "J.Lima", "P.Martinez", "M.Hampton", "M.Mussina", "T.Glavine", "D.Cone", "S.Reynolds", "G.Maddux" );
leaderTeam31 = new Array( "CHN", "CHN", "HON", "HON", "MON", "HON", "ATN", "HON", "NYN", "ATN" );
leaderData31 = new Array( "292.1", "282.0", "269.2", "266.0", "254.2", "250.0", "249.1", "246.2", "245.1", "241.1" );

leaderName32 = new Array( "R.Johnson", "K.Brown", "J.Lima", "T.Glavine", "M.Hampton", "M.Mussina", "G.Maddux", "D.Cone", "S.Reynolds", "P.Martinez" );
leaderTeam32 = new Array( "CHN", "CHN", "HON", "ATN", "MON", "HON", "ATN", "HON", "NYN", "HON" );
leaderData32 = new Array( "1209", "1147", "1118", "1099", "1091", "1076", "1073", "1058", "1053", "1029" );

leaderName33 = new Array( "U.Urbina", "A.Benitez", "J.Powell", "S.Williamson", "J.Rocker", "G.Swindell", "R.White", "M.Magnante", "M.Stanton", "B.Groom" );
leaderTeam33 = new Array( "MON", "MON", "SDN", "CIN", "ATN", "LAN", "MON", "SDN", "SDN", "SDN" );
leaderData33 = new Array( "88", "76", "76", "73", "70", "70", "70", "70", "69", "69" );

leaderName34 = new Array( "T.Glavine", "R.Johnson", "K.Brown", "J.Lima", "R.Helling", "M.Hampton", "S.Reynolds", "D.Burba", "D.Hermanson", "G.Maddux" );
leaderTeam34 = new Array( "ATN", "CHN", "CHN", "HON", "LAN", "MON", "NYN", "CIN", "MON", "ATN" );
leaderData34 = new Array( "35", "35", "35", "35", "35", "35", "35", "34", "34", "33" );

leaderName35 = new Array( "R.Johnson", "P.Martinez", "K.Brown", "J.Lima", "M.Mussina", "D.Cone", "J.Smoltz", "W.Alvarez", "T.Glavine", "G.Maddux" );
leaderTeam35 = new Array( "CHN", "HON", "CHN", "HON", "HON", "HON", "NYN", "PHN", "ATN", "ATN" );
leaderData35 = new Array( "26", "22", "20", "15", "15", "13", "11", "10", "9", "9" );

leaderName36 = new Array( "G.Swindell", "S.Williamson", "M.Stanton", "J.Rocker", "J.Zimmerman", "A.Benitez", "R.Hernandez", "B.Wagner", "A.Embree", "M.Mantei" );
leaderTeam36 = new Array( "LAN", "CIN", "SDN", "ATN", "CHN", "MON", "NYN", "HON", "SFN", "PIN" );
leaderData36 = new Array( "67", "66", "55", "51", "51", "51", "51", "46", "46", "45" );

leaderName37 = new Array( "R.Hernandez", "M.Stanton", "G.Swindell", "M.Mantei", "A.Embree", "J.Zimmerman", "A.Benitez", "S.Williamson", "A.Alfonseca", "J.Rocker" );
leaderTeam37 = new Array( "NYN", "SDN", "LAN", "PIN", "SFN", "CHN", "MON", "CIN", "SLN", "ATN" );
leaderData37 = new Array( "39", "35", "32", "30", "30", "28", "27", "22", "19", "18" );

leaderName38 = new Array( "R.Hernandez", "A.Embree", "M.Stanton", "A.Benitez", "J.Zimmerman", "M.Mantei", "J.Rocker", "G.Swindell", "A.Alfonseca", "B.Wagner" );
leaderTeam38 = new Array( "NYN", "SFN", "SDN", "MON", "CHN", "PIN", "ATN", "LAN", "SLN", "HON" );
leaderData38 = new Array( ".929", ".909", ".897", ".844", ".824", ".811", ".692", ".681", ".679", ".583" );

leaderName39 = new Array( "P.Martinez", "G.Maddux", "R.Johnson", "R.Ortiz", "R.Rupe", "S.Trachsel", "K.Brown", "J.Moyer", "J.Lima", "M.Mussina" );
leaderTeam39 = new Array( "HON", "ATN", "CHN", "SFN", "ATN", "CHN", "CHN", "CHN", "HON", "HON" );
leaderData39 = new Array( "5", "3", "3", "3", "2", "2", "2", "2", "2", "2" );

leaderName40 = new Array( "G.Maddux", "S.Reynolds", "T.Glavine", "J.Lima", "M.Mussina", "R.Johnson", "J.Moyer", "R.Person", "J.Lieber", "I.Valdes" );
leaderTeam40 = new Array( "ATN", "NYN", "ATN", "HON", "HON", "CHN", "CHN", "PHN", "PIN", "LAN" );
leaderData40 = new Array( "301", "295", "280", "278", "270", "257", "247", "247", "247", "239" );

leaderName41 = new Array( "R.Person", "J.Lieber", "T.Glavine", "K.Benson", "J.Witasick", "D.Kile", "S.Reynolds", "J.Schmidt", "G.Maddux", "S.Estes" );
leaderTeam41 = new Array( "PHN", "PIN", "ATN", "PIN", "PHN", "SLN", "NYN", "SFN", "ATN", "SFN" );
leaderData41 = new Array( "162", "150", "148", "144", "142", "142", "140", "137", "135", "135" );

leaderName42 = new Array( "R.Person", "J.Lieber", "T.Glavine", "S.Reynolds", "K.Benson", "J.Witasick", "M.Clement", "S.Estes", "C.Park", "D.Kile" );
leaderTeam42 = new Array( "PHN", "PIN", "ATN", "NYN", "PIN", "PHN", "SDN", "SFN", "LAN", "SLN" );
leaderData42 = new Array( "155", "144", "142", "140", "133", "132", "124", "124", "123", "122" );

leaderName43 = new Array( "R.Person", "R.Johnson", "R.Helling", "D.Burba", "D.Cone", "S.Reynolds", "J.Lieber", "B.Tomko", "T.Wakefield", "J.Moyer" );
leaderTeam43 = new Array( "PHN", "CHN", "LAN", "CIN", "HON", "NYN", "PIN", "CIN", "SLN", "CHN" );
leaderData43 = new Array( "51", "40", "39", "38", "35", "34", "34", "33", "33", "32" );

leaderName44 = new Array( "R.Person", "R.Ortiz", "C.Park", "D.Kile", "M.Hampton", "D.Cone", "S.Avery", "K.Benson", "W.Alvarez", "J.Guzman" );
leaderTeam44 = new Array( "PHN", "SFN", "LAN", "SLN", "MON", "HON", "SLN", "PIN", "PHN", "SDN" );
leaderData44 = new Array( "153", "130", "112", "112", "111", "109", "101", "99", "98", "96" );

leaderName45 = new Array( "P.Martinez", "R.Johnson", "D.Cone", "K.Brown", "M.Mussina", "S.Reynolds", "R.Person", "S.Williamson", "J.Smoltz", "J.Lima" );
leaderTeam45 = new Array( "HON", "CHN", "HON", "CHN", "HON", "NYN", "PHN", "CIN", "NYN", "HON" );
leaderData45 = new Array( "379", "361", "235", "228", "203", "199", "196", "190", "169", "168" );

leaderName46 = new Array( "S.Williamson", "A.Telemaco", "C.Park", "R.Ortiz", "C.Reyes", "J.Guzman", "S.Estes", "K.Cloude", "J.Rocker", "C.Leskanic" );
leaderTeam46 = new Array( "CIN", "PHN", "LAN", "SFN", "LAN", "SDN", "SFN", "PHN", "ATN", "PIN" );
leaderData46 = new Array( "15", "15", "14", "14", "13", "13", "13", "12", "11", "11" );

leaderName47 = new Array( "J.Silva", "S.Trachsel", "O.Dotel", "D.Dreifort", "K.Benson", "D.Oliver", "J.Guzman", "J.Schmidt", "D.Cone", "J.Witasick" );
leaderTeam47 = new Array( "PIN", "CHN", "HON", "LAN", "PIN", "SLN", "SDN", "SFN", "HON", "PHN" );
leaderData47 = new Array( "8", "5", "5", "5", "5", "5", "4", "4", "3", "3" );

leaderName48 = new Array( "M.Mussina", "D.Cone", "P.Martinez", "C.Park", "D.Hermanson", "H.Nomo", "T.Ritchie", "J.Lieber", "M.Yoshii", "R.Ortiz" );
leaderTeam48 = new Array( "HON", "HON", "HON", "LAN", "MON", "MON", "PIN", "PIN", "SLN", "SFN" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00", "1.00" );

leaderName49 = new Array( "R.Johnson", "J.Guzman", "R.Rupe", "H.Nomo", "A.Leiter", "T.Wakefield", "R.Helling", "J.Smoltz", "D.Mlicki", "K.Brown" );
leaderTeam49 = new Array( "CHN", "SDN", "ATN", "MON", "NYN", "SLN", "LAN", "NYN", "LAN", "CHN" );
leaderData49 = new Array( "47", "44", "34", "34", "33", "32", "31", "31", "30", "29" );

leaderName50 = new Array( "S.Parris", "D.Burba", "D.Kile", "J.Johnson", "R.Helling", "G.Maddux", "J.Smoltz", "K.Brown", "K.Benson", "R.Ortiz" );
leaderTeam50 = new Array( "CIN", "CIN", "SLN", "SDN", "LAN", "ATN", "NYN", "CHN", "PIN", "SFN" );
leaderData50 = new Array( ".62", ".67", ".67", ".67", ".67", ".70", ".70", ".71", ".73", ".75" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "P.Martinez", "S.Williamson", "K.Brown", "D.Cone", "R.Johnson", "M.Hampton", "J.Smoltz", "D.Dreifort", "R.Rupe", "J.Guzman" );
leaderTeam53 = new Array( "HON", "CIN", "CHN", "HON", "CHN", "MON", "NYN", "LAN", "ATN", "SDN" );
leaderData53 = new Array( " 6.2", " 7.4", " 7.4", " 7.7", " 7.9", " 8.2", " 8.5", " 8.5", " 8.5", " 8.6" );

leaderName54 = new Array( "P.Martinez", "J.Lima", "S.Reynolds", "I.Valdes", "J.Moyer", "J.Lieber", "G.Maddux", "J.Smoltz", "K.Brown", "M.Mussina" );
leaderTeam54 = new Array( "HON", "HON", "NYN", "LAN", "CHN", "PIN", "ATN", "NYN", "CHN", "HON" );
leaderData54 = new Array( " 1.4", " 1.8", " 1.8", " 2.1", " 2.2", " 2.2", " 2.2", " 2.3", " 2.6", " 2.6" );

leaderName55 = new Array( "P.Martinez", "R.Johnson", "S.Williamson", "R.Clemens", "H.Nomo", "D.Cone", "R.Person", "W.Alvarez", "M.Mussina", "J.Lieber" );
leaderTeam55 = new Array( "HON", "CHN", "CIN", "MON", "MON", "HON", "PHN", "PHN", "HON", "PIN" );
leaderData55 = new Array( "12.8", "11.1", "10.4", " 8.9", " 8.8", " 8.6", " 8.4", " 7.8", " 7.3", " 7.3" );

leaderName56 = new Array( "M.Hampton", "D.Oliver", "J.Lima", "P.Martinez", "D.Dreifort", "K.Brown", "D.Mlicki", "T.Glavine", "H.Nomo", "A.Leiter" );
leaderTeam56 = new Array( "MON", "SLN", "HON", "HON", "LAN", "CHN", "LAN", "ATN", "MON", "NYN" );
leaderData56 = new Array( " 0.60", " 0.65", " 0.87", " 0.88", " 0.89", " 0.89", " 0.92", " 0.94", " 0.94", " 0.96" );

