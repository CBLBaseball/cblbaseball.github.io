sub = new Array( "AL", "NL" );
sublong = new Array( "American League", "National League" );

AL = new Array( "ALEast", "ALCentral", "ALWest" );
NL = new Array( "NLEast", "NLCentral", "NLWest" );

ALALEast = new Array( "BAA", "BOA", "NYA", "TOA" );

BAA = new Array("ALEast", "Baltimore", "Orioles", "Baltimore Orioles (BAA)", "2000", "162", "65", "97", ".401", ".383", ".420" );
BOA = new Array("ALEast", "Boston", "Red Sox", "Boston Red Sox (BOA)", "2000", "162", "95", "67", ".586", ".494", ".679" );
NYA = new Array("ALEast", "New York (AL)", "Yankees", "New York (AL) Yankees (NYA)", "2000", "162", "92", "70", ".568", ".469", ".667" );
TOA = new Array("ALEast", "Toronto", "Blue Jays", "Toronto Blue Jays (TOA)", "2000", "162", "74", "88", ".457", ".420", ".494" );
ALALCentral = new Array( "CHA", "CLA", "DEA", "MNA" );

CHA = new Array("ALCentral", "Chicago (AL)", "White Sox", "Chicago (AL) White Sox (CHA)", "2000", "162", "91", "71", ".562", ".469", ".654" );
CLA = new Array("ALCentral", "Cleveland", "Indians", "Cleveland Indians (CLA)", "2000", "162", "97", "65", ".599", ".568", ".630" );
DEA = new Array("ALCentral", "Detroit", "Tigers", "Detroit Tigers (DEA)", "2000", "162", "84", "78", ".519", ".481", ".556" );
MNA = new Array("ALCentral", "Minnesota", "Twins", "Minnesota Twins (MNA)", "2000", "162", "61", "101", ".377", ".407", ".346" );
ALALWest = new Array( "ANA", "KCA", "OAA", "SEA" );

ANA = new Array("ALWest", "Anaheim", "Angels", "Anaheim Angels (ANA)", "2000", "162", "53", "109", ".327", ".358", ".296" );
KCA = new Array("ALWest", "Kansas City", "Royals", "Kansas City Royals (KCA)", "2000", "162", "84", "78", ".519", ".494", ".543" );
OAA = new Array("ALWest", "Oakland", "Athletics", "Oakland Athletics (OAA)", "2000", "162", "97", "65", ".599", ".519", ".679" );
SEA = new Array("ALWest", "Seattle", "Mariners", "Seattle Mariners (SEA)", "2000", "162", "79", "83", ".488", ".457", ".519" );
NLNLEast = new Array( "ATN", "MON", "NYN", "PHN" );

ATN = new Array("NLEast", "Atlanta", "Braves", "Atlanta Braves (ATN)", "2000", "162", "79", "83", ".488", ".481", ".494" );
MON = new Array("NLEast", "Montreal", "Expos", "Montreal Expos (MON)", "2000", "162", "95", "67", ".586", ".519", ".654" );
NYN = new Array("NLEast", "New York (NL)", "Mets", "New York (NL) Mets (NYN)", "2000", "162", "93", "69", ".574", ".519", ".630" );
PHN = new Array("NLEast", "Philadelphia", "Phillies", "Philadelphia Phillies (PHN)", "2000", "162", "33", "129", ".204", ".210", ".198" );
NLNLCentral = new Array( "CHN", "CIN", "PIN", "SLN" );

CHN = new Array("NLCentral", "Chicago (NL)", "Cubs", "Chicago (NL) Cubs (CHN)", "2000", "162", "113", "49", ".698", ".704", ".691" );
CIN = new Array("NLCentral", "Cincinnati", "Reds", "Cincinnati Reds (CIN)", "2000", "162", "91", "71", ".562", ".531", ".593" );
PIN = new Array("NLCentral", "Pittsburgh", "Pirates", "Pittsburgh Pirates (PIN)", "2000", "162", "77", "85", ".475", ".457", ".494" );
SLN = new Array("NLCentral", "St. Louis", "Cardinals", "St. Louis Cardinals (SLN)", "2000", "162", "53", "109", ".327", ".383", ".272" );
NLNLWest = new Array( "HON", "LAN", "SDN", "SFN" );

HON = new Array("NLWest", "Houston", "Astros", "Houston Astros (HON)", "2000", "162", "110", "52", ".679", ".667", ".691" );
LAN = new Array("NLWest", "Los Angeles", "Dodgers", "Los Angeles Dodgers (LAN)", "2000", "162", "92", "70", ".568", ".506", ".630" );
SDN = new Array("NLWest", "San Diego", "Padres", "San Diego Padres (SDN)", "2000", "162", "69", "93", ".426", ".346", ".506" );
SFN = new Array("NLWest", "San Francisco", "Giants", "San Francisco Giants (SFN)", "2000", "162", "67", "95", ".414", ".395", ".432" );
