// User Data
var myLeague = "My Strat-O-Matic League";	
var mylogo = "my_logo.gif";
var toplogo = "stratomatic.jpg"
var toptext = "2000 SEASON!!!";
var backColor = "LightSteelBlue";			  
var bargraph = "green.gif";
  