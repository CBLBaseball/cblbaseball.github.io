leaderName0 = new Array( "N.Garciaparra", "L.Gonzalez", "M.Sweeney", "F.Thomas", "S.Green", "C.Singleton", "D.Jeter", "H.Bush", "L.Walker", "J.Vidro" );
leaderTeam0 = new Array( "BOA", "DEA", "KCA", "CHA", "SEA", "CHA", "NYA", "TOA", "CHA", "SEA" );
leaderData0 = new Array( ".354", ".352", ".348", ".347", ".337", ".335", ".334", ".329", ".326", ".321" );

leaderName1 = new Array( "J.Randa", "M.Ordonez", "R.Ventura", "D.Cruz", "C.Beltran", "L.Gonzalez", "O.Vizquel", "J.Vidro", "J.Cirillo", "R.Velarde" );
leaderTeam1 = new Array( "KCA", "CHA", "CHA", "DEA", "KCA", "DEA", "CLA", "SEA", "OAA", "OAA" );
leaderData1 = new Array( "655", "648", "644", "644", "642", "634", "633", "629", "623", "622" );

leaderName2 = new Array( "M.McGwire", "B.Giles", "S.Green", "J.Thome", "M.Ramirez", "L.Gonzalez", "J.Damon", "M.Sweeney", "B.Anderson", "T.Fernandez" );
leaderTeam2 = new Array( "OAA", "SEA", "SEA", "CLA", "CLA", "DEA", "KCA", "KCA", "BAA", "CLA" );
leaderData2 = new Array( "139", "134", "134", "123", "122", "118", "118", "116", "115", "115" );

leaderName3 = new Array( "L.Gonzalez", "M.Sweeney", "S.Green", "J.Vidro", "J.Cirillo", "D.Jeter", "N.Garciaparra", "O.Vizquel", "H.Bush", "R.Velarde" );
leaderTeam3 = new Array( "DEA", "KCA", "SEA", "SEA", "OAA", "NYA", "BOA", "CLA", "TOA", "OAA" );
leaderData3 = new Array( "223", "209", "206", "202", "200", "199", "196", "196", "196", "192" );

leaderName4 = new Array( "J.Vidro", "L.Gonzalez", "M.Sweeney", "C.Delgado", "J.Varitek", "S.Green", "R.Greer", "T.Fernandez", "C.Singleton", "T.Helton" );
leaderTeam4 = new Array( "SEA", "DEA", "KCA", "SEA", "BOA", "SEA", "NYA", "CLA", "CHA", "CHA" );
leaderData4 = new Array( "61", "54", "53", "52", "49", "49", "48", "46", "43", "43" );

leaderName5 = new Array( "D.Jeter", "M.Cameron", "J.Damon", "A.Gonzalez", "M.Tucker", "R.Clayton", "T.Nixon", "R.White", "L.Polonia", "R.Sexson" );
leaderTeam5 = new Array( "NYA", "SEA", "KCA", "MNA", "BAA", "BAA", "BOA", "CLA", "DEA", "BAA" );
leaderData5 = new Array( "15", "15", "13", "12", "9", "9", "9", "9", "9", "8" );

leaderName6 = new Array( "M.McGwire", "S.Green", "M.Ramirez", "B.Giles", "A.Rodriguez", "C.Delgado", "J.Canseco", "R.Rivera", "J.Thome", "H.Baines" );
leaderTeam6 = new Array( "OAA", "SEA", "CLA", "SEA", "SEA", "SEA", "CLA", "ANA", "CLA", "KCA" );
leaderData6 = new Array( "69", "51", "47", "46", "45", "43", "40", "38", "37", "37" );

leaderName7 = new Array( "M.McGwire", "M.Ramirez", "S.Green", "C.Delgado", "J.Thome", "A.Rodriguez", "B.Giles", "H.Baines", "A.Belle", "J.Giambi" );
leaderTeam7 = new Array( "OAA", "CLA", "SEA", "SEA", "CLA", "SEA", "SEA", "KCA", "BAA", "OAA" );
leaderData7 = new Array( "169", "151", "134", "134", "122", "119", "118", "116", "113", "112" );

leaderName8 = new Array( "M.McGwire", "J.Thome", "G.Sheffield", "B.Giles", "J.Jaha", "J.Giambi", "A.Belle", "D.Jeter", "B.Anderson", "F.Thomas" );
leaderTeam8 = new Array( "OAA", "CLA", "NYA", "SEA", "OAA", "OAA", "BAA", "NYA", "BAA", "CHA" );
leaderData8 = new Array( "149", "124", "93", "93", "92", "91", "86", "86", "85", "85" );

leaderName9 = new Array( "M.McGwire", "A.Belle", "H.Baines", "L.Walker", "M.Ramirez", "S.Rolen", "J.Burnitz", "C.Delgado", "A.Ledesma", "T.Eusebio" );
leaderTeam9 = new Array( "OAA", "BAA", "KCA", "CHA", "CLA", "DEA", "DEA", "SEA", "ANA", "BAA" );
leaderData9 = new Array( "29", "6", "5", "4", "3", "3", "3", "3", "2", "2" );

leaderName10 = new Array( "R.Rivera", "J.Thome", "M.Ramirez", "M.McGwire", "R.Becker", "C.Delgado", "J.Canseco", "M.Vaughn", "T.Clark", "T.Glaus" );
leaderTeam10 = new Array( "ANA", "CLA", "CLA", "OAA", "OAA", "SEA", "CLA", "BOA", "DEA", "ANA" );
leaderData10 = new Array( "169", "167", "159", "150", "143", "141", "140", "138", "137", "132" );

leaderName11 = new Array( "B.Anderson", "L.Walker", "J.Burnitz", "M.Ramirez", "D.Easley", "D.Jeter", "F.Seguignol", "J.Guillen", "M.Sweeney", "C.Knoblauch" );
leaderTeam11 = new Array( "BAA", "CHA", "DEA", "CLA", "DEA", "NYA", "SEA", "BAA", "KCA", "NYA" );
leaderData11 = new Array( "25", "23", "22", "20", "17", "16", "16", "15", "15", "15" );

leaderName12 = new Array( "J.Girardi", "M.Johnson", "C.Guzman", "G.Disarcina", "J.Vizcaino", "D.Bell", "O.Vizquel", "E.Wilson", "C.Febles", "T.Bogar" );
leaderTeam12 = new Array( "NYA", "CHA", "MNA", "ANA", "KCA", "SEA", "CLA", "CLA", "SEA", "BAA" );
leaderData12 = new Array( "13", "11", "9", "7", "7", "6", "5", "5", "5", "4" );

leaderName13 = new Array( "Q.Veras", "H.Bush", "E.Owens", "O.Vizquel", "J.Damon", "M.Cameron", "M.Lawton", "C.Beltran", "T.Hunter", "R.Rivera" );
leaderTeam13 = new Array( "ANA", "TOA", "ANA", "CLA", "KCA", "SEA", "MNA", "KCA", "MNA", "ANA" );
leaderData13 = new Array( "64", "60", "44", "44", "41", "34", "33", "32", "30", "29" );

leaderName14 = new Array( "L.Johnson", "S.Green", "C.Beltran", "T.Hunter", "Q.Veras", "O.Vizquel", "M.Lawton", "C.Singleton", "B.Anderson", "J.Damon" );
leaderTeam14 = new Array( "TOA", "SEA", "KCA", "MNA", "ANA", "CLA", "MNA", "CHA", "BAA", "KCA" );
leaderData14 = new Array( ".91", ".88", ".86", ".86", ".83", ".83", ".82", ".81", ".81", ".80" );

leaderName15 = new Array( "R.Durham", "D.Easley", "R.Velarde", "J.Cirillo", "T.O'Leary", "A.Belle", "C.Beltran", "N.Garciaparra", "H.Baines", "R.Brogna" );
leaderTeam15 = new Array( "CHA", "DEA", "OAA", "OAA", "BOA", "BAA", "KCA", "BOA", "KCA", "MNA" );
leaderData15 = new Array( "30", "29", "29", "28", "26", "25", "25", "24", "24", "24" );

leaderName16 = new Array( "J.Thome", "H.Bush", "D.Segui", "B.Daubach", "L.Polonia", "C.Ripken Jr.", "D.Jeter", "R.Hernandez", "J.Cruz", "J.Varitek" );
leaderTeam16 = new Array( "CLA", "TOA", "TOA", "BOA", "DEA", "BAA", "NYA", "OAA", "SEA", "BOA" );
leaderData16 = new Array( "15", "15", "12", "10", "10", "9", "8", "8", "8", "7" );

leaderName17 = new Array( "J.Hammonds", "J.Jones", "", "", "", "", "", "", "", "" );
leaderTeam17 = new Array( "CLA", "MNA", "", "", "", "", "", "", "", "" );
leaderData17 = new Array( ".364", ".273", "0", "0", "0", "0", "0", "0", "0", "0" );

leaderName18 = new Array( "M.McGwire", "S.Green", "L.Walker", "J.Canseco", "C.Delgado", "B.Giles", "M.Ramirez", "A.Rodriguez", "L.Gonzalez", "M.Sweeney" );
leaderTeam18 = new Array( "OAA", "SEA", "CHA", "CLA", "SEA", "SEA", "CLA", "SEA", "DEA", "KCA" );
leaderData18 = new Array( ".690", ".668", ".621", ".621", ".620", ".614", ".609", ".608", ".606", ".582" );

leaderName19 = new Array( "F.Thomas", "M.Sweeney", "D.Jeter", "L.Walker", "M.McGwire", "L.Gonzalez", "J.Giambi", "S.Green", "J.Thome", "M.Ramirez" );
leaderTeam19 = new Array( "CHA", "KCA", "NYA", "CHA", "OAA", "DEA", "OAA", "SEA", "CLA", "CLA" );
leaderData19 = new Array( ".444", ".428", ".426", ".420", ".419", ".416", ".411", ".409", ".407", ".404" );

leaderName20 = new Array( "S.Green", "M.McGwire", "L.Gonzalez", "M.Sweeney", "L.Walker", "F.Thomas", "M.Ramirez", "C.Delgado", "B.Giles", "D.Jeter" );
leaderTeam20 = new Array( "SEA", "OAA", "DEA", "KCA", "CHA", "CHA", "CLA", "SEA", "SEA", "NYA" );
leaderData20 = new Array( "10.3", "10.1", " 9.9", " 9.9", " 9.5", " 9.5", " 9.3", " 9.3", " 9.2", " 9.1" );

leaderName21 = new Array( "M.McGwire", "S.Green", "L.Walker", "M.Ramirez", "L.Gonzalez", "B.Giles", "M.Sweeney", "C.Delgado", "D.Jeter", "J.Canseco" );
leaderTeam21 = new Array( "OAA", "SEA", "CHA", "CLA", "DEA", "SEA", "KCA", "SEA", "NYA", "CLA" );
leaderData21 = new Array( "1.245", "1.192", "1.118", "1.092", "1.081", "1.078", "1.076", "1.068", "1.039", "1.033" );

leaderName22 = new Array( "S.Green", "L.Gonzalez", "M.McGwire", "C.Delgado", "M.Ramirez", "M.Sweeney", "B.Giles", "N.Garciaparra", "J.Vidro", "T.O'Leary" );
leaderTeam22 = new Array( "SEA", "DEA", "OAA", "SEA", "CLA", "KCA", "SEA", "BOA", "SEA", "BOA" );
leaderData22 = new Array( "408", "384", "378", "374", "356", "349", "348", "319", "314", "310" );

leaderName23 = new Array( "C.Singleton", "L.Walker", "M.Sweeney", "T.O'Leary", "N.Garciaparra", "R.Velarde", "M.Cameron", "M.Ramirez", "S.Javier", "J.Damon" );
leaderTeam23 = new Array( "CHA", "CHA", "KCA", "BOA", "BOA", "OAA", "SEA", "CLA", "TOA", "KCA" );
leaderData23 = new Array( ".441", ".411", ".405", ".394", ".387", ".375", ".371", ".366", ".366", ".366" );

leaderName24 = new Array( "M.McGwire", "J.Canseco", "B.Huskey", "M.Cameron", "R.Rivera", "M.Ramirez", "E.Clemente", "J.Cirillo", "S.Green", "C.Singleton" );
leaderTeam24 = new Array( "OAA", "CLA", "BOA", "SEA", "ANA", "CLA", "CLA", "OAA", "SEA", "CHA" );
leaderData24 = new Array( "19", "15", "14", "14", "11", "10", "10", "10", "10", "9" );

leaderName25 = new Array( "L.Gonzalez", "D.Jeter", "S.Green", "F.Thomas", "N.Garciaparra", "M.Sweeney", "J.Vidro", "C.Delgado", "O.Vizquel", "B.Giles" );
leaderTeam25 = new Array( "DEA", "NYA", "SEA", "CHA", "BOA", "KCA", "SEA", "SEA", "CLA", "SEA" );
leaderData25 = new Array( ".363", ".359", ".359", ".355", ".342", ".335", ".326", ".322", ".319", ".315" );

leaderName26 = new Array( "M.McGwire", "B.Giles", "S.Green", "M.Ramirez", "A.Rodriguez", "J.Thome", "L.Gonzalez", "C.Delgado", "H.Baines", "A.Belle" );
leaderTeam26 = new Array( "OAA", "SEA", "SEA", "CLA", "SEA", "CLA", "DEA", "SEA", "KCA", "BAA" );
leaderData26 = new Array( "50", "41", "41", "37", "36", "35", "34", "34", "32", "28" );

leaderName27 = new Array( "K.Millwood", "O.Hernandez", "G.Heredia", "M.Sirotka", "B.Colon", "J.Rosado", "O.Daal", "E.Milton", "A.Benes", "J.Suppan" );
leaderTeam27 = new Array( "OAA", "NYA", "OAA", "CHA", "CLA", "KCA", "KCA", "MNA", "NYA", "BOA" );
leaderData27 = new Array( "22", "20", "20", "19", "16", "15", "15", "15", "15", "14" );

leaderName28 = new Array( "S.Erickson", "F.Cordova", "B.Radke", "F.Garcia", "L.Hawkins", "K.McGlinchy", "K.Rogers", "S.Ponson", "J.Jimenez", "B.Bohanon" );
leaderTeam28 = new Array( "BAA", "CHA", "MNA", "SEA", "ANA", "ANA", "ANA", "BAA", "BAA", "BAA" );
leaderData28 = new Array( "18", "16", "16", "16", "15", "14", "14", "14", "14", "14" );

leaderName29 = new Array( "J.Halama", "S.Karsay", "B.Colon", "M.Sirotka", "G.Heredia", "B.Wells", "K.Millwood", "R.Cormier", "O.Hernandez", "M.Oquist" );
leaderTeam29 = new Array( "SEA", "CLA", "CLA", "CHA", "OAA", "DEA", "OAA", "BOA", "NYA", "OAA" );
leaderData29 = new Array( ".778", ".765", ".727", ".704", ".690", ".688", ".688", ".667", ".667", ".667" );

leaderName30 = new Array( "O.Hernandez", "K.Millwood", "J.Halama", "S.Hitchcock", "C.Schilling", "W.Williams", "M.Sirotka", "O.Olivares", "G.Heredia", "E.Milton" );
leaderTeam30 = new Array( "NYA", "OAA", "SEA", "NYA", "CHA", "TOA", "CHA", "DEA", "OAA", "MNA" );
leaderData30 = new Array( " 2.82", " 3.09", " 3.63", " 3.96", " 3.99", " 4.08", " 4.13", " 4.16", " 4.21", " 4.31" );

leaderName31 = new Array( "K.Millwood", "O.Hernandez", "S.Hitchcock", "S.Erickson", "B.Radke", "G.Heredia", "J.Rosado", "F.Garcia", "E.Milton", "A.Benes" );
leaderTeam31 = new Array( "OAA", "NYA", "NYA", "BAA", "MNA", "OAA", "KCA", "SEA", "MNA", "NYA" );
leaderData31 = new Array( "265.1", "249.0", "234.1", "233.0", "231.2", "228.2", "227.1", "222.0", "221.1", "220.1" );

leaderName32 = new Array( "K.Millwood", "S.Erickson", "O.Hernandez", "S.Hitchcock", "B.Radke", "J.Rosado", "F.Garcia", "G.Heredia", "P.Astacio", "E.Milton" );
leaderTeam32 = new Array( "OAA", "BAA", "NYA", "NYA", "MNA", "KCA", "SEA", "OAA", "OAA", "MNA" );
leaderData32 = new Array( "1080", "1035", "1021", "1000", "992", "991", "990", "978", "961", "956" );

leaderName33 = new Array( "M.Remlinger", "R.Nen", "P.Shuey", "D.Lowe", "M.Venafro", "K.McGlinchy", "J.Shaw", "B.Wells", "D.Wall", "A.Telford" );
leaderTeam33 = new Array( "TOA", "BOA", "CLA", "BOA", "BOA", "ANA", "CLA", "DEA", "ANA", "BAA" );
leaderData33 = new Array( "82", "78", "74", "72", "72", "71", "67", "67", "66", "64" );

leaderName34 = new Array( "S.Erickson", "A.Sele", "K.Appier", "E.Milton", "P.Astacio", "P.Hentgen", "L.Hawkins", "B.Bohanon", "J.Suppan", "C.Finley" );
leaderTeam34 = new Array( "BAA", "BOA", "KCA", "MNA", "OAA", "TOA", "ANA", "BAA", "BOA", "CLA" );
leaderData34 = new Array( "34", "34", "34", "34", "34", "34", "33", "33", "33", "33" );

leaderName35 = new Array( "K.Millwood", "O.Hernandez", "O.Daal", "J.Rosado", "C.Schilling", "A.Benes", "S.Erickson", "M.Sirotka", "S.Hitchcock", "G.Heredia" );
leaderTeam35 = new Array( "OAA", "NYA", "KCA", "KCA", "CHA", "NYA", "BAA", "CHA", "NYA", "OAA" );
leaderData35 = new Array( "19", "17", "14", "12", "11", "10", "9", "9", "9", "9" );

leaderName36 = new Array( "D.Lowe", "J.Shaw", "R.Aguilera", "K.Foulke", "S.Montgomery", "B.Looper", "M.Timlin", "T.Hoffman", "B.Koch", "T.Percival" );
leaderTeam36 = new Array( "BOA", "CLA", "MNA", "CHA", "KCA", "SEA", "BAA", "OAA", "TOA", "ANA" );
leaderData36 = new Array( "63", "52", "52", "51", "49", "49", "45", "45", "43", "40" );

leaderName37 = new Array( "D.Lowe", "J.Shaw", "T.Hoffman", "T.Percival", "B.Koch", "K.Foulke", "R.Aguilera", "M.Rivera", "M.Timlin", "B.Looper" );
leaderTeam37 = new Array( "BOA", "CLA", "OAA", "ANA", "TOA", "CHA", "MNA", "NYA", "BAA", "SEA" );
leaderData37 = new Array( "42", "33", "32", "29", "29", "28", "25", "25", "24", "24" );

leaderName38 = new Array( "R.Aguilera", "T.Percival", "D.Lowe", "M.Timlin", "K.Foulke", "T.Hoffman", "S.Montgomery", "B.Howry", "M.Rivera", "B.Koch" );
leaderTeam38 = new Array( "MNA", "ANA", "BOA", "BAA", "CHA", "OAA", "KCA", "CHA", "NYA", "TOA" );
leaderData38 = new Array( ".893", ".879", ".840", ".828", ".824", ".821", ".815", ".813", ".806", ".806" );

leaderName39 = new Array( "O.Daal", "O.Hernandez", "K.Millwood", "S.Ponson", "B.Saberhagen", "A.Benes", "T.Hudson", "H.Irabu", "K.Rogers", "S.Erickson" );
leaderTeam39 = new Array( "KCA", "NYA", "OAA", "BAA", "BOA", "NYA", "OAA", "ANA", "ANA", "BAA" );
leaderData39 = new Array( "5", "3", "3", "2", "2", "2", "2", "1", "1", "1" );

leaderName40 = new Array( "B.Radke", "P.Astacio", "L.Hawkins", "G.Heredia", "S.Erickson", "A.Ashby", "A.Sele", "J.Rosado", "S.Ponson", "B.Bohanon" );
leaderTeam40 = new Array( "MNA", "OAA", "ANA", "OAA", "BAA", "CHA", "BOA", "KCA", "BAA", "BAA" );
leaderData40 = new Array( "274", "269", "263", "257", "251", "247", "243", "242", "241", "240" );

leaderName41 = new Array( "S.Ponson", "S.Erickson", "A.Sele", "P.Astacio", "L.Hawkins", "J.Rosado", "C.Finley", "F.Garcia", "A.Ashby", "B.Bohanon" );
leaderTeam41 = new Array( "BAA", "BAA", "BOA", "OAA", "ANA", "KCA", "CLA", "SEA", "CHA", "BAA" );
leaderData41 = new Array( "144", "142", "141", "140", "138", "138", "134", "134", "130", "129" );

leaderName42 = new Array( "S.Ponson", "P.Astacio", "A.Sele", "J.Rosado", "S.Erickson", "F.Garcia", "L.Hawkins", "A.Ashby", "C.Finley", "P.Hentgen" );
leaderTeam42 = new Array( "BAA", "OAA", "BOA", "KCA", "BAA", "SEA", "ANA", "CHA", "CLA", "TOA" );
leaderData42 = new Array( "132", "132", "129", "129", "128", "128", "123", "121", "118", "118" );

leaderName43 = new Array( "A.Ashby", "P.Astacio", "B.Radke", "S.Ponson", "J.Fassero", "H.Irabu", "L.Hawkins", "J.Suppan", "F.Garcia", "P.Hentgen" );
leaderTeam43 = new Array( "CHA", "OAA", "MNA", "BAA", "SEA", "ANA", "ANA", "BOA", "SEA", "TOA" );
leaderData43 = new Array( "38", "37", "36", "35", "35", "34", "33", "33", "33", "33" );

leaderName44 = new Array( "F.Garcia", "S.Erickson", "R.Dempster", "A.Pettitte", "O.Hernandez", "K.Hill", "O.Olivares", "C.Finley", "O.Daal", "S.Hitchcock" );
leaderTeam44 = new Array( "SEA", "BAA", "SEA", "NYA", "NYA", "ANA", "DEA", "CLA", "KCA", "NYA" );
leaderData44 = new Array( "117", "116", "107", "106", "95", "90", "89", "88", "87", "84" );

leaderName45 = new Array( "K.Millwood", "S.Hitchcock", "O.Hernandez", "E.Milton", "C.Finley", "F.Garcia", "C.Schilling", "R.Dempster", "J.Rosado", "P.Astacio" );
leaderTeam45 = new Array( "OAA", "NYA", "NYA", "MNA", "CLA", "SEA", "CHA", "SEA", "KCA", "OAA" );
leaderData45 = new Array( "223", "201", "188", "178", "177", "174", "169", "169", "165", "165" );

leaderName46 = new Array( "C.Carpenter", "F.Garcia", "S.Hitchcock", "D.Veres", "A.Benes", "W.Williams", "J.Jimenez", "P.Shuey", "C.Finley", "A.Rhodes" );
leaderTeam46 = new Array( "TOA", "SEA", "NYA", "ANA", "NYA", "TOA", "BAA", "CLA", "CLA", "BAA" );
leaderData46 = new Array( "19", "18", "17", "14", "14", "13", "12", "12", "12", "11" );

leaderName47 = new Array( "O.Daal", "G.Mota", "F.Garcia", "B.Kim", "R.Ortiz", "C.Nitkowski", "O.Perez", "P.Hentgen", "P.Byrd", "R.Roque" );
leaderTeam47 = new Array( "KCA", "KCA", "SEA", "SEA", "ANA", "DEA", "SEA", "TOA", "CLA", "KCA" );
leaderData47 = new Array( "5", "5", "5", "5", "4", "4", "4", "4", "3", "3" );

leaderName48 = new Array( "L.Hawkins", "H.Irabu", "F.Cordova", "C.Schilling", "B.Radke", "E.Milton", "B.Bohanon", "W.Williams", "O.Daal", "O.Hernandez" );
leaderTeam48 = new Array( "ANA", "ANA", "CHA", "CHA", "MNA", "MNA", "BAA", "TOA", "KCA", "NYA" );
leaderData48 = new Array( "1.00", "1.00", "1.00", "1.00", "1.00", ".88", ".82", ".80", ".75", ".75" );

leaderName49 = new Array( "P.Astacio", "K.Millwood", "D.Wells", "K.Hill", "B.Bohanon", "P.Rapp", "F.Garcia", "A.Sele", "T.Stottlemyre", "A.Ashby" );
leaderTeam49 = new Array( "OAA", "OAA", "DEA", "ANA", "BAA", "DEA", "SEA", "BOA", "ANA", "CHA" );
leaderData49 = new Array( "48", "43", "40", "36", "32", "32", "28", "26", "24", "23" );

leaderName50 = new Array( "K.Appier", "D.Eiland", "J.Suppan", "S.Erickson", "F.Garcia", "H.Irabu", "P.Harnisch", "R.Arrojo", "A.Benes", "L.Hawkins" );
leaderTeam50 = new Array( "KCA", "OAA", "BOA", "BAA", "SEA", "ANA", "DEA", "MNA", "NYA", "ANA" );
leaderData50 = new Array( ".62", ".63", ".64", ".64", ".65", ".68", ".70", ".70", ".71", ".71" );

leaderName51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam51 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData51 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderTeam52 = new Array( "", "", "", "", "", "", "", "", "", "" );
leaderData52 = new Array( "", "", "", "", "", "", "", "", "", "" );

leaderName53 = new Array( "O.Hernandez", "K.Millwood", "R.Dempster", "E.Milton", "S.Hitchcock", "C.Schilling", "A.Benes", "J.Halama", "W.Williams", "M.Sirotka" );
leaderTeam53 = new Array( "NYA", "OAA", "SEA", "MNA", "NYA", "CHA", "NYA", "SEA", "TOA", "CHA" );
leaderData53 = new Array( " 6.7", " 7.2", " 8.0", " 8.2", " 8.5", " 8.6", " 8.8", " 9.0", " 9.1", " 9.4" );

leaderName54 = new Array( "B.Radke", "G.Heredia", "J.Suppan", "A.Ashby", "C.Schilling", "K.Millwood", "J.Halama", "P.Astacio", "L.Hawkins", "W.Williams" );
leaderTeam54 = new Array( "MNA", "OAA", "BOA", "CHA", "CHA", "OAA", "SEA", "OAA", "ANA", "TOA" );
leaderData54 = new Array( " 1.7", " 1.8", " 2.4", " 2.5", " 2.5", " 2.7", " 2.7", " 2.7", " 2.8", " 2.9" );

leaderName55 = new Array( "C.Finley", "R.Dempster", "C.Schilling", "A.Sele", "S.Hitchcock", "K.Millwood", "E.Milton", "F.Garcia", "P.Astacio", "J.Jimenez" );
leaderTeam55 = new Array( "CLA", "SEA", "CHA", "BOA", "NYA", "OAA", "MNA", "SEA", "OAA", "BAA" );
leaderData55 = new Array( " 9.2", " 8.7", " 8.0", " 8.0", " 7.7", " 7.6", " 7.2", " 7.1", " 6.8", " 6.8" );

leaderName56 = new Array( "A.Pettitte", "O.Hernandez", "J.Halama", "O.Olivares", "S.Karl", "K.Millwood", "B.Meadows", "M.Sirotka", "O.Daal", "A.Sele" );
leaderTeam56 = new Array( "NYA", "NYA", "SEA", "DEA", "NYA", "OAA", "BOA", "CHA", "KCA", "BOA" );
leaderData56 = new Array( " 0.67", " 0.80", " 0.83", " 0.86", " 0.87", " 0.88", " 0.96", " 0.99", " 1.03", " 1.05" );

