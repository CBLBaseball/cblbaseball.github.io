//	Copyright 2002 (c) Strat-O-Matic Game Co.
//	Knowledge of HMTL and Javascript is recommended before editing this document
//	Be sure to make backup copies before any changes
//  For use with Web Builder 1.3
	
document.write("<SCR" + "IPT LANGUAGE=JAVASCRIPT1.1 src='" + dataFile + "'></SCR" + "IPT>");

